#Code for Reference
#Training Client Data
#To identify dependency of Lead volume on other parameters

#This model can be used for Ad Words data with the following metrics 
#Day,Budget,Cost,Impressions,Clicks,CTR,Avg..CPC,Conversions



#Creating a Linear Regression Model

#Libraries 
#install.packages('ggplot2') -> for Plot Visualisation
library(ggplot2)
#install.packages('tidyverse') -> For Data Cleaning and Manipulating Tasks
library(tidyverse)
#install.packages('lubridate') 
library(lubridate)
#install.packages('caTools') -> for Modelling purpose
library(caTools)
#install.packages('lattice') -> for general data analysis
library(lattice)

#Reading Data
  Client = read.csv('TrainWelspun.csv')
  str(Client)

#Missing values
  colSums(is.na(Client))
  colSums(Client=="")

#Changing lead values to integer
  Client$Conversions = round(Client$Conversions)
  table(Client$Conversions)

#Date Manipulation
  Client$Day = as.Date(Client$Day,"%d-%m-%y")
  Client$Month = as.factor(format(Client$Day,"%B") )
  Client$Month = factor(Client$Month , levels = c("August", "September", "October", "November"))

#Our CTR improves MOM implying optimization work.
  with(Client,tapply(CTR, Month,mean))
#Our Lead Volumes Increase. This indicates that optimization and ad changes led to better results over time. 
  with(Client,tapply(Conversions,Month,sum))
#Our Spends Increase. This indicates that optimization and ad changes led to better results over time.
  with(Client,tapply(Cost,Month,sum))

#Segmenting data into bins for classification and later use in trees and CART model
#Also need to anonymiZe the data.
  Client$CostFactor = cut(Client$Cost,5,include.lowest = T,labels = c("Lowest","Low","Medium","High","V High")) 
  Client$ImprFactor = cut(Client$Impressions,5,include.lowest = T, labels = c("Lowest","Low","Medium","High","V High"))
  Client$ClickFactor = cut(Client$Clicks,5,include.lowest = T, labels = c("Lowest","Low","Medium","High","V High"))
  Client$ConvFactor = cut(Client$Cost,3,include.lowest = T, labels = c("low","Medium","High"))


# Checking how many features we can move to factors
  apply(Client,2, function(x) length(unique(x)))
#This is a general query for a more extensive data

#Basic Plots for Understanding Data
  chartLeads <- density(Client$Conversions)
  plot(chartLeads)
#% of leads >= 5
  histLeads <-hist(Client$Conversions, xlab = "Leads", main = 'Density of Leads(>5)', col = 'yellow', border = 'blue', freq = FALSE, xlim = c(5,20), ylim = c(0,0.05))
  lines(chartLeads)

#Understanding Distribution of Conversions
  ggplot(data = Client,aes(x=(Conversions)))+
  geom_bar(position="fill")+
  ylab("Frequency")+
  facet_wrap(~Month, ncol=2)+
  labs(x = "Conversions", title = 'Conversion Frequency By Month')+
  geom_histogram(bins=20)

#Removing Day Column since we wont be doing time series analysis and using this to find correlation matrix
subset = head(Client[-1],1215)

cor(subset)     
plot((Client$Cost),(Client$Conversions), col = 'red', pch = 20, xlab = 'Spends', ylab='Leads', main = 'Spends Vs Leads', ylim = c(5,35), xlim = c(3000,10000))

#Splitting data into train and test sets
  split = sample.split(Client$Conversions, SplitRatio = 0.7)
  train = subset(Client, split == TRUE)
  test = subset(Client, split == FALSE)
  #Model
  model1 = lm((Conversions) ~ Cost + CTR + Avg..CPC, data = train)
  abline(model1, lty = 5, lwd = 4, col = 'blue')
  summary(model1)

#TRAINING SET PREDICTIONS-------------------------------------------------------------------------------------------------------

    #Using data for predictions and confusion matrix
    predTrain = round(predict(model1))
    
    
    #Leads cannot be less than 0 so changing those values
    predTrain [predTrain  < 0] = 0
    train$LeadPrediction =  predTrain 
    
    
    #Model Accuracy on Training Set
    confusionMatrix <-table(train$Conversions,predTrain)
    confusionMatrix
    #Variables defined
    sumCorrectPred  = 0
    rowCount = ncol(confusionMatrix)-1
    colCount = nrow(confusionMatrix)-1
    
    #Diagonal Sum
    for(i in 1:(rowCount - 1)){  # need an expression that retruns a sequence
      for (j in 1:colCount)      # ditto
        if (i == j){
          sumCorrectPred = confusionMatrix[i,j]+sumCorrectPred;  # need to index the matrix with two element if using i,j
        }
    }
    
    sumCorrectPred/sum(train$Conversions) # 39.43% accuracy on Training Set

#TRAINING SET PREDICTIONS END-------------------------------------------------------------------------------------------------------
    
#TEST SET PREDICTIONS---------------------------------------------------------------------------------------------------------------

    #Using data for predictions and confusion matrix on Testing Set
      predTest = round(predict(model1, newdata = test))
    
    
    #Leads cannot be less than 0 so changing those values
      predTest [predTest  < 0] = 0
      test$LeadPrediction =  predTest 
    
    
    #Model Accuracy on Training Set
      confusionMatrixTest <-table(test$Conversions,predTest)
    
      #Variables defined
        sumCorrectPred  = 0
        rowCount = ncol(confusionMatrixTest)-1
        colCount = nrow(confusionMatrixTest)-1
      
      #Diagonal Sum
        for(i in 1:(rowCount - 1)){  # need an expression that returns a sequence
          for (j in 1:colCount)      # ditto
            if (i == j){
              sumCorrectPred = confusionMatrix[i,j]+sumCorrectPred;  # need to index the matrix with two element if using i,j
            }
        }
    
    #Accuracy of Model
      sumCorrectPred/sum(test$Conversions) # 92.92% accuracy on Testing Set
      SSE = sum((predTest-test$Conversions)**2)
      RMSE = sqrt(SSE/nrow(test))
      SST = sum((predTest-mean(test$Conversions))**2) 
  
#TEST SET PREDICTIONS END---------------------------------------------------------------------------------------------------------------

#Faceted Plot Visualizations for better understanding-----------------------------------------------------------------------------------
     #Understanding relation with Impressions 
      Client %>% ggplot(aes(x =(Cost) , y = (Impressions), color = Month, size = Conversions))+
      geom_point(alpha=.5)+ 
      labs(x = "Cost", y="Impressions", title = 'Cost vs Impressions')+
      scale_x_log10()+
      coord_cartesian(xlim = c(1000,20000))+
      theme_bw(base_size = 16)+
      facet_wrap(~Month, ncol=2)+
      geom_hline(yintercept = 1000)+geom_vline(xintercept = 3000)
    #Outliers in October month indicate branding campaign. Unfortunately the data does not contain any classifier to distinguish them.
    
    #All points falling on y =0 line indicates branding campaigns. 
    #This is a generalization as we do not have any other classifier to distinguish them from lead campaigns
      Client %>% ggplot(aes(x =Cost , y = Conversions, color = Month, size = Conversions))+
      geom_point(alpha=.5)+
      labs(x = "Spends", y="Conversions", title = 'Spends vs Conversions')+
      scale_x_log10()+
      coord_cartesian(xlim = c(1000,20000))+
      theme_bw(base_size = 16)+
      facet_wrap(~Month, ncol=2)+
      geom_hline(yintercept = 0, col = 'red')
    
    #Understanding the relation with Budget 
      Client %>% ggplot(aes(x =(Budget) , y = (Impressions), color = ClickFactor, size = Conversions))+
      geom_point(alpha=.5)+ 
      labs(x = "Budget", y="Impressions", title = 'Budget vs Impressions')+
      scale_x_log10()+
      coord_cartesian(xlim = c(1000,20000))+
      theme_bw(base_size = 16)+
      facet_wrap(~Month, ncol=2)+
      geom_vline(xintercept = 1500)

#END-----------------------------------------------------------------------------------------------------------------------------------------
